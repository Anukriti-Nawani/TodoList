import React, { useEffect, useState } from 'react'



const Archive = () => {
    const [tasks, setTasks] = useState(JSON.parse(localStorage.getItem("todoData"))|| []);

    useEffect = () => {
        
    }

  return (
    <div>
      {
        tasks?.map((item) => {
return (
    <h1>{item.title}</h1>
)
        })
      }
    </div>
  )
}

export default Archive
