import React from 'react'
import TodoList from './NewTodo'


const Home = () => {
  return (
    <div>
      <TodoList/>
    </div>
  )
}

export default Home
