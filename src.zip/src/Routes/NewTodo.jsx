import React, { useState } from "react";
import { Box, Button, Input, Text } from '@chakra-ui/react'
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

function TodoList() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState("");
  const navigate = useNavigate()
const [selectedDate, setSelectedDate] = useState("");
const archiveData =  JSON.parse(localStorage.getItem("todoData")) || [];




  const handleNewTaskChange = (event) => {
    setNewTask(event.target.value);
  };

const handleDateChange = (event) => {
  
  //let currentDate = new Date().toLocaleDateString().split("/").sort().join("-");
    setSelectedDate(event.target.value);
    let newDate =event.target.value.split("-").sort((a,b)=>a-b).join("-").slice(1,10)
    // console.log(newDate)
    const filteredData = tasks.map((task) =>task.date ===newDate?{id:task.id,title:task.title,date:task.date,show:true}:{id:task.id,title:task.title,date:task.date,show:false});
    console.log(filteredData)
    setTasks(filteredData);
  };

  // const filterDate = () => {
  
  // }

  const addTask = () => {
    const newId = tasks.length + 1;
   
    // current date
    const date = new Date().toLocaleDateString().split("/").sort((a,b)=>a-b).join("-");
    // console.log(date)
    const newTaskObject = { id: newId, title: newTask, date:date,show:true};
    
    console.log(newTaskObject)
   setTasks([...tasks, newTaskObject]);
    // localStorage.setItem("todoData", JSON.stringify(tasks))
setNewTask("");
  };

  const deleteTask = (taskId) => {
    const updatedTasks = tasks.filter((task) => task.id !== taskId);
    setTasks(updatedTasks);
    // localStorage.setItem("todoData", JSON.stringify(tasks))

    alert("Task deleted");
  };

  const editTask = (taskId, newTitle) => {
    const updatedTasks = tasks.map((task) =>

      task.id === taskId ? { ...task, title: newTitle } : task
    );
    setTasks(updatedTasks);
    //console.log(updatedTasks)
    // localStorage.setItem("todoData", JSON.stringify(tasks))

  };

  const edit = (id) => {
// console.log(id)
const newData = prompt("edit task")

if(newData !== null) {
    // console.log(newData)
    editTask(id,newData)
}
  }

  const archiveTask = (taskId) => {
    const updatedTasks = tasks.filter((task) =>
      task.id !== taskId 
      
    );
const updation = tasks.filter((task) =>
      task.id === taskId 
    )
    setTasks(updatedTasks);
    //console.log(tasks)
    archiveData.push(updation[0]);
    localStorage.setItem("todoData", JSON.stringify(archiveData))

   
    alert('task archived')
    navigate('/archive')
    //console.log(updatedTasks)
    //console.log(archivedTasks)

  };
 

  

//   const filteredTasks = tasks.filter((task) => task.date === selectedDate);


  return (
    <Box>
      <Text>To-Do List</Text>
            <div>
         <label htmlFor="date">Select Date:</label>
         <input
         
          type="date" 
          
          id="date"
          value={selectedDate}
          onChange={handleDateChange}
        />
      </div>
      <ul>{tasks.map((item) => {
        if(item.show===false) return;
        return (
            <li key={item.id}>
        <h3>{item.title}</h3>
                

        <Button colorScheme='blue' mr='1rem' onClick={() =>edit(item.id)}>Edit</Button>
        <Button mr='1rem' onClick={() => deleteTask(item.id)} colorScheme='red' size='md'>Delete</Button>
        <Button  colorScheme='blue' onClick={() => archiveTask(item.id)}>Archive</Button>
      </li>
        )
      })}</ul>
      
      
      <Input mr='1rem' mt='2rem'  width='auto' type="text" value={newTask} onChange={handleNewTaskChange}/>
      
      <Button onClick={addTask} colorScheme='teal' size='md'>
      Add Task
  </Button>
    </Box>
  );
    }

 export default TodoList;