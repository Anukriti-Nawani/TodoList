import logo from './logo.svg';
import './App.css';
import TodoList from './components/Todo';
import NewTodoList from './Routes/NewTodo';
import Archive from './Routes/Archive';
import AllRoutes from './Routes/AllRoutes';

function App() {
  return (
    <div className="App">
      {/* <TodoList/> */}
      <AllRoutes/>
      {/* <NewTodoList/>   */}
      {/* <Archive /> */}
    </div>
  );
}

export default App;
