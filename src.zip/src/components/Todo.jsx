import React, { useState } from "react";
import { Box, Button, Input, Text } from '@chakra-ui/react'

function TodoList() {
    const [tasks, setTasks] = useState([]);
    const [newTask, setNewTask] = useState("");

//adding task
const addTask = () => {
    const newId = tasks.length + 1;
    const newTaskObject = { id: newId, title: newTask, archived: false };
    setTasks([...tasks, newTaskObject]);
    setNewTask("");
  };

  return (
    <div>
      {
        tasks.map((task) => {
            return (
                
                <li key={task.id}>
                    <h1>todo list</h1>
                <input
                  type="text"
                  value={task.title}
                  onChange={(event) => setNewTask(event.target.value)}
                />
                        
        
               <button onClick={addTask}>Add task</button>
              </li>
            )
        }
)}
    </div>
  )

 
}
export default TodoList;

